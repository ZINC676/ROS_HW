Description of the Super Mega Bot used for ROS course and summer school.  

If you use velodyne please install the ros package `velodyne_description`.  
If you want to run the tf publisher please install `joint_state_publisher_gui`.